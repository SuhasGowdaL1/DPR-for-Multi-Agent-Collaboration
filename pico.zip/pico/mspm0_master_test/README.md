# TI MSPM0 I²C Master Test Suite for RP2040 64 KB EEPROM Emulator

This directory contains a C-based test application for the **Texas Instruments MSPM0 microcontroller** (configured as an I²C controller/master). It validates the correctness of the emulated 64 KB Pico EEPROM (acting as an I²C target/slave), including:
1. 16-bit memory address handling.
2. Sequential read address auto-incrementing.
3. 128-byte page write roll-over/wrap-around.
4. Acknowledge polling (write delay NACK handling).

---

## 1. Wiring Mappings

Connect the TI MSPM0 LaunchPad to the Raspberry Pi Pico (RP2040) using these connections:

```
    +-----------------------+                    +-----------------------+
    |  TI MSPM0 LaunchPad   |                    |   Raspberry Pi Pico   |
    |      (I2C Master)     |                    |      (EEPROM Slave)   |
    |                       |                    |                       |
    |      SDA (PA0 / PA10) |<------------------>| GP4 (I2C SDA)         |
    |      SCL (PA1 / PA11) |<------------------>| GP5 (I2C SCL)         |
    |      GND              |<------------------>| GND                   |
    +-----------------------+                    +-----------------------+
```
*Note: Make sure both SDA and SCL lines are connected to pull-up resistors (typically 2.2kΩ to 4.7kΩ to 3.3V) to enable standard open-drain signaling.*

---

## 2. Pin and Peripheral Definitions (SysConfig)

When configuring the project in CCS (Code Composer Studio) using the TI SysConfig tool, configure the following:

### I²C Peripheral (`I2C0`):
* **Mode**: Controller (Master)
* **Pin Mappings**:
  * **SDA**: PA0 (or PA10 depending on package)
  * **SCL**: PA1 (or PA11 depending on package)
* **Speed**: Standard Mode (100 kHz)

### UART Peripheral (`UART0`):
* **Baudrate**: 115200 bps
* **Data Bits**: 8
* **Parity**: None
* **Stop Bits**: 1

### GPIO Peripherals:
* **LED2 Red Pin**: Output pin driving the onboard Red LED (LaunchPad LED2 Red).
* **LED2 Green Pin**: Output pin driving the onboard Green LED (LaunchPad LED2 Green).

---

## 3. Test Cases Executed

### Test 1: Single Byte Write & Read
* Writes `0x55` to memory address `0x1234` (verifying 16-bit address serialization).
* Wait-busy polls the device address (Acknowledge Polling) to wait out the 5 ms write delay.
* Reads the byte back from `0x1234` and asserts that it matches `0x55`.

### Test 2: Sequential Write & Read
* Writes 10 bytes sequentially (`0x10` to `0xA0`) at address `0x0000`.
* Reads all 10 bytes back in a single sequential read transaction to verify address auto-incrementing.

### Test 3: Page wrapping (128-byte bounds)
* Performs a page write of 4 bytes (`0xAA`, `0xBB`, `0xCC`, `0xDD`) starting at address `0x000FD` (which is 3 bytes before the 128-byte page boundary at `0x00100`).
* Verifies that:
  - Address `0x000FD` gets `0xAA` (normal).
  - Address `0x000FE` gets `0xBB` (normal).
  - Address `0x000FF` gets `0xCC` (boundary).
  - Address `0x00080` gets `0xDD` (wrapped to start of page).
  - Address `0x00100` is untouched (value remains `0xFF`), proving page wrapping prevents page boundary spillover.

---

## 4. Build and Running Instructions

1. Open Code Composer Studio (CCS) or CCS Theia.
2. Select **File -> Import -> CCS Projects**.
3. Import the standard TI SDK DriverLib example `i2c_controller_rw_multibyte_fifo_poll` for your specific MSPM0 board.
4. Replace the original `main.c` file in that project with the [main.c](file:///c:/Users/91701/OneDrive/Desktop/pico/mspm0_master_test/main.c) from this directory.
5. In the project's SysConfig tool, configure the SCL, SDA, UART, and LED pins to match your physical board configuration.
6. Build and flash the project onto the MSPM0 LaunchPad.
7. Open a serial monitor terminal (e.g. PuTTY or CCS Terminal) on the virtual COM port representing the MSPM0 debug probe at **115200 baud**.
8. Press the Reset button on the LaunchPad. The test log will print on the serial monitor, and the onboard LED will light up **Green** for success or **Red** if any assertion fails.
