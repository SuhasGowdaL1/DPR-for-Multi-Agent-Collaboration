#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "ti_msp_dl_config.h"

#define EEPROM_I2C_ADDRESS 0x50
#define EEPROM_PAGE_SIZE   128

void uart_print(const char *str);
void uart_print_hex(uint32_t val);

bool eeprom_ping(I2C_Regs *i2c);
bool eeprom_write_byte(I2C_Regs *i2c, uint32_t addr, uint8_t data);
bool eeprom_read_bytes(I2C_Regs *i2c, uint32_t addr, uint8_t *buffer, uint32_t len);
void eeprom_wait_busy(I2C_Regs *i2c);

bool run_test_suite(I2C_Regs *i2c, const char *interface_name);
bool assert_data(const char *test_name, uint32_t addr, uint8_t expected, uint8_t actual);

int main(void)
{
    SYSCFG_DL_init();

    uart_print("\n========================================================\n");
    uart_print("  MSPM0 I2C EEPROM (64KB, 16-bit Addr) Dual-Port Test    \n");
    uart_print("========================================================\n");

    bool any_tested = false;
    bool all_passed = true;

    // 1. Test I2C0_INST
    uart_print("Checking for EEPROM on I2C0...\n");
    if (eeprom_ping(I2C0_INST))
    {
        uart_print("EEPROM detected on I2C0. Running tests...\n");
        any_tested = true;
        if (run_test_suite(I2C0_INST, "I2C0"))
        {
            uart_print("I2C0 tests PASSED.\n");
        }
        else
        {
            uart_print("I2C0 tests FAILED.\n");
            all_passed = false;
        }
    }
    else
    {
        uart_print("No EEPROM detected on I2C0. Skipping.\n");
    }

    uart_print("\n");

    // 2. Test I2C1_INST
    uart_print("Checking for EEPROM on I2C1...\n");
    if (eeprom_ping(I2C1_INST))
    {
        uart_print("EEPROM detected on I2C1. Running tests...\n");
        any_tested = true;
        if (run_test_suite(I2C1_INST, "I2C1"))
        {
            uart_print("I2C1 tests PASSED.\n");
        }
        else
        {
            uart_print("I2C1 tests FAILED.\n");
            all_passed = false;
        }
    }
    else
    {
        uart_print("No EEPROM detected on I2C1. Skipping.\n");
    }

    uart_print("\n========================================================\n");
    if (any_tested && all_passed)
    {
        uart_print("     ALL DETECTED INTERFACES PASSED SUCCESSFULLY!\n");
        DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED2_GREEN_PIN);
        DL_GPIO_clearPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED2_RED_PIN);
    }
    else
    {
        if (!any_tested)
        {
            uart_print("     ERROR: NO EEPROM DETECTED ON EITHER INTERFACE!\n");
        }
        else
        {
            uart_print("     TEST SUITE FAILED. CHECK PICO CONNECTIONS.\n");
        }
        DL_GPIO_setPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED2_RED_PIN);
        DL_GPIO_clearPins(GPIO_LEDS_PORT, GPIO_LEDS_USER_LED2_GREEN_PIN);
    }
    uart_print("========================================================\n");

    while (1)
    {
        __WFI();
    }
}

bool run_test_suite(I2C_Regs *i2c, const char *interface_name)
{
    bool suite_passed = true;

    // TEST 1: Single Byte Write & Read
    uart_print("[TEST 1] Single Byte Write & Read at 0x1234...\n");
    uint32_t test_addr1 = 0x1234;
    uint8_t write_val1 = 0x55;
    uint8_t read_val1 = 0;

    if (!eeprom_write_byte(i2c, test_addr1, write_val1))
    {
        uart_print("  FAIL: I2C Write transaction NACK'd or failed\n");
        suite_passed = false;
    }
    else
    {
        eeprom_wait_busy(i2c);

        if (!eeprom_read_bytes(i2c, test_addr1, &read_val1, 1))
        {
            uart_print("  FAIL: I2C Read transaction failed\n");
            suite_passed = false;
        }
        else
        {
            suite_passed &= assert_data("Test 1 Byte Verification", test_addr1, write_val1, read_val1);
        }
    }

    // TEST 2: Sequential Write and Read
    uart_print("\n[TEST 2] Sequential Write and Read (10 bytes starting at 0x0000)...\n");
    uint32_t test_addr2 = 0x0000;
    uint8_t write_buffer2[10] = {0x10, 0x20, 0x30, 0x40, 0x50, 0x60, 0x70, 0x80, 0x90, 0xA0};
    uint8_t read_buffer2[10] = {0};

    bool write_ok = true;
    for (int i = 0; i < 10; i++)
    {
        if (!eeprom_write_byte(i2c, test_addr2 + i, write_buffer2[i]))
        {
            write_ok = false;
            break;
        }
        eeprom_wait_busy(i2c);
    }

    if (!write_ok)
    {
        uart_print("  FAIL: Writing sequence failed\n");
        suite_passed = false;
    }
    else
    {
        if (!eeprom_read_bytes(i2c, test_addr2, read_buffer2, 10))
        {
            uart_print("  FAIL: Sequential read failed\n");
            suite_passed = false;
        }
        else
        {
            for (int i = 0; i < 10; i++)
            {
                suite_passed &= assert_data("Sequential Verify", test_addr2 + i, write_buffer2[i], read_buffer2[i]);
            }
        }
    }

    // TEST 3: Page Wrapping Validation
    uart_print("\n[TEST 3] Page wrapping validation at 0x000FD...\n");
    uint32_t test_addr3 = 0x000FD;
    uint8_t write_buffer3[4] = {0xAA, 0xBB, 0xCC, 0xDD};

    DL_I2C_clearControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_ALL);
    DL_I2C_transmitControllerData(i2c, (test_addr3 >> 8) & 0xFF);
    DL_I2C_transmitControllerData(i2c, test_addr3 & 0xFF);
    for (int i = 0; i < 4; i++)
    {
        DL_I2C_transmitControllerData(i2c, write_buffer3[i]);
    }

    DL_I2C_startControllerTransfer(i2c, EEPROM_I2C_ADDRESS, DL_I2C_CONTROLLER_DIRECTION_TX, 6);

    while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
        ;

    if (DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK))
    {
        uart_print("  FAIL: Page Write transaction NACK'd\n");
        suite_passed = false;
    }
    else
    {
        eeprom_wait_busy(i2c);

        uint8_t read_fd = 0, read_fe = 0, read_ff = 0, read_80 = 0, read_100 = 0;

        eeprom_read_bytes(i2c, 0x000FD, &read_fd, 1);
        eeprom_read_bytes(i2c, 0x000FE, &read_fe, 1);
        eeprom_read_bytes(i2c, 0x000FF, &read_ff, 1);
        eeprom_read_bytes(i2c, 0x00080, &read_80, 1);
        eeprom_read_bytes(i2c, 0x00100, &read_100, 1);

        suite_passed &= assert_data("Addr 0xFD (normal)", 0x000FD, 0xAA, read_fd);
        suite_passed &= assert_data("Addr 0xFE (normal)", 0x000FE, 0xBB, read_fe);
        suite_passed &= assert_data("Addr 0xFF (boundary)", 0x000FF, 0xCC, read_ff);
        suite_passed &= assert_data("Addr 0x80 (wrapped)", 0x00080, 0xDD, read_80);

        if (read_100 == 0xDD)
        {
            uart_print("  FAIL: Addr 0x100 was modified; page wrap failed!\n");
            suite_passed = false;
        }
        else
        {
            uart_print("  PASS: Addr 0x100 was untouched.\n");
        }
    }

    return suite_passed;
}

bool eeprom_ping(I2C_Regs *i2c)
{
    DL_I2C_clearControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_ALL);

    // Send a single dummy byte to probe device presence
    DL_I2C_transmitControllerData(i2c, 0x00);
    DL_I2C_startControllerTransfer(i2c, EEPROM_I2C_ADDRESS, DL_I2C_CONTROLLER_DIRECTION_TX, 1);

    while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
        ;

    return !DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK);
}

bool eeprom_write_byte(I2C_Regs *i2c, uint32_t addr, uint8_t data)
{
    DL_I2C_clearControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_ALL);

    // Serialize 16-bit address + 1 data byte
    DL_I2C_transmitControllerData(i2c, (addr >> 8) & 0xFF);
    DL_I2C_transmitControllerData(i2c, addr & 0xFF);
    DL_I2C_transmitControllerData(i2c, data);

    DL_I2C_startControllerTransfer(i2c, EEPROM_I2C_ADDRESS, DL_I2C_CONTROLLER_DIRECTION_TX, 3);

    while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
        ;

    return !DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK);
}

bool eeprom_read_bytes(I2C_Regs *i2c, uint32_t addr, uint8_t *buffer, uint32_t len)
{
    DL_I2C_clearControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_ALL);

    // Phase 1: Write target 16-bit address without generating a STOP condition
    DL_I2C_transmitControllerData(i2c, (addr >> 8) & 0xFF);
    DL_I2C_transmitControllerData(i2c, addr & 0xFF);

    DL_I2C_startControllerTransferAdvanced(
        i2c,
        EEPROM_I2C_ADDRESS,
        DL_I2C_CONTROLLER_DIRECTION_TX,
        2,
        DL_I2C_CONTROLLER_START_ENABLE,
        DL_I2C_CONTROLLER_STOP_DISABLE,
        DL_I2C_CONTROLLER_ACK_ENABLE);

    while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
        ;

    if (DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK))
    {
        return false;
    }

    // Phase 2: Start Repeated START read transfer for 'len' bytes
    DL_I2C_startControllerTransferAdvanced(
        i2c,
        EEPROM_I2C_ADDRESS,
        DL_I2C_CONTROLLER_DIRECTION_RX,
        len,
        DL_I2C_CONTROLLER_START_ENABLE,
        DL_I2C_CONTROLLER_STOP_ENABLE,
        DL_I2C_CONTROLLER_ACK_ENABLE);

    for (uint32_t i = 0; i < len; i++)
    {
        while (DL_I2C_isControllerRXFIFOEmpty(i2c))
        {
            if (DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK))
            {
                return false;
            }
        }
        buffer[i] = DL_I2C_receiveControllerData(i2c);
    }

    while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
        ;

    return true;
}

void eeprom_wait_busy(I2C_Regs *i2c)
{
    while (true)
    {
        DL_I2C_clearControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_ALL);

        DL_I2C_transmitControllerData(i2c, 0x00);
        DL_I2C_startControllerTransfer(i2c, EEPROM_I2C_ADDRESS, DL_I2C_CONTROLLER_DIRECTION_TX, 1);

        while (DL_I2C_getControllerStatus(i2c) & DL_I2C_CONTROLLER_STATUS_BUSY_AND_ENABLED)
            ;

        if (!DL_I2C_getControllerInterruptStatus(i2c, DL_I2C_CONTROLLER_INTERRUPT_NACK))
        {
            break;
        }

        delay_cycles(1000);
    }
}

bool assert_data(const char *test_name, uint32_t addr, uint8_t expected, uint8_t actual)
{
    if (expected == actual)
    {
        uart_print("  PASS: [");
        uart_print(test_name);
        uart_print("] Address: 0x");
        uart_print_hex(addr);
        uart_print(" expected=0x");
        uart_print_hex(expected);
        uart_print(" actual=0x");
        uart_print_hex(actual);
        uart_print("\n");
        return true;
    }
    else
    {
        uart_print("  FAIL: [");
        uart_print(test_name);
        uart_print("] Address: 0x");
        uart_print_hex(addr);
        uart_print(" expected=0x");
        uart_print_hex(expected);
        uart_print(" actual=0x");
        uart_print_hex(actual);
        uart_print("\n");
        return false;
    }
}

void uart_print(const char *str)
{
    while (*str)
    {
        DL_UART_transmitDataBlocking(UART0_INST, *str++);
    }
}

void uart_print_hex(uint32_t val)
{
    char buf[9];
    int idx = 8;
    buf[idx--] = '\0';

    if (val == 0)
    {
        buf[idx--] = '0';
    }
    else
    {
        while (val > 0 && idx >= 0)
        {
            uint8_t digit = val & 0xF;
            buf[idx--] = (digit < 10) ? ('0' + digit) : ('A' + digit - 10);
            val >>= 4;
        }
    }

    uart_print(&buf[idx + 1]);
}
