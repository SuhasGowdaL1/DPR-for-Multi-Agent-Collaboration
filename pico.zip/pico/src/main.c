/**
 * @file main.c
 * @brief Firmware entry point initializing dual I2C controllers as slaves sharing the same 64 KB context.
 * @copyright Copyright (c) 2026
 */

#include <stdio.h>
#include <pico/stdlib.h>
#include <hardware/gpio.h>
#include <hardware/i2c.h>
#include <pico/i2c_slave.h>
#include "config.h"
#include "eeprom_emulator.h"
#include "i2c_slave_handler.h"

/**
 * @brief Firmware entry function.
 * @details Initializes system resources, enables debugging logs, sets up GPIO multiplexing
 * and internal pull-ups for both I2C0 and I2C1, initializes both blocks in Slave mode,
 * and enters the main background scheduler polling loop.
 * 
 * @return Standard execution return status code.
 */
int main(void) {
    // Initialize standard input/output (UART/USB CDC) for print logging
    stdio_init_all();
    
    // Slight boot delay to allow PC USB host controllers to mount virtual serial COM
    sleep_ms(2000);
    
    printf("\n");
    printf("====================================================================\n");
    printf("     RP2040/Pico Dual-I2C 64 KB EEPROM Emulator Firmware            \n");
    printf("====================================================================\n");
    
    // 1. Initialize emulated memory space and internal registers
    eeprom_emulator_init();
    
    // 2. Initialize physical I2C controller hardwares
    i2c_init(i2c0, EEPROM_I2C_BAUDRATE);
    i2c_init(i2c1, EEPROM_I2C_BAUDRATE);
    
    // 3. Configure GPIO pin multiplexing for I2C0 pins
    gpio_set_function(EEPROM_I2C0_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(EEPROM_I2C0_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(EEPROM_I2C0_SDA_PIN);
    gpio_pull_up(EEPROM_I2C0_SCL_PIN);
    
    // Configure GPIO pin multiplexing for I2C1 pins
    gpio_set_function(EEPROM_I2C1_SDA_PIN, GPIO_FUNC_I2C);
    gpio_set_function(EEPROM_I2C1_SCL_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(EEPROM_I2C1_SDA_PIN);
    gpio_pull_up(EEPROM_I2C1_SCL_PIN);
    
    // 4. Put both I2C blocks into Slave mode and register the interrupt handler callback
    i2c_slave_init(i2c0, EEPROM_I2C_ADDRESS, &i2c_slave_handler);
    i2c_slave_init(i2c1, EEPROM_I2C_ADDRESS, &i2c_slave_handler);
    
    LOG_INFO("I2C0 peripheral SDA=GP%d, SCL=GP%d bound and active.\n", 
             EEPROM_I2C0_SDA_PIN, EEPROM_I2C0_SCL_PIN);
    LOG_INFO("I2C1 peripheral SDA=GP%d, SCL=GP%d bound and active.\n", 
             EEPROM_I2C1_SDA_PIN, EEPROM_I2C1_SCL_PIN);
    LOG_INFO("Firmware online. Emulating 64 KB (16-bit addressing). Ready...\n");
    printf("====================================================================\n");
    
    // Main execution worker loop
    while (true) {
        // Run background tasks (write cycle delay, etc.)
        eeprom_emulator_process_background();
        
        // Yield CPU thread to avoid CPU heating / starvation
        tight_loop_contents();
    }
    
    return 0;
}
