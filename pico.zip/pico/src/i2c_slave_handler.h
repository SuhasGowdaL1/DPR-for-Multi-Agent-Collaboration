#ifndef I2C_SLAVE_HANDLER_H
#define I2C_SLAVE_HANDLER_H

#include <hardware/i2c.h>
#include <pico/i2c_slave.h>

/**
 * @brief Callback handler triggered by the Pico SDK I2C slave interrupt.
 * Runs in interrupt context (ISR) and must execute quickly.
 * 
 * @param i2c The I2C instance (i2c0 or i2c1) triggering the event.
 * @param event The event type (I2C_SLAVE_RECEIVE, I2C_SLAVE_REQUEST, or I2C_SLAVE_FINISH).
 */
void i2c_slave_handler(i2c_inst_t *i2c, i2c_slave_event_t event);

#endif // I2C_SLAVE_HANDLER_H
