/**
 * @file i2c_slave_handler.c
 * @brief Interrupt service routines managing separate state machine tracks for dual I2C buses (64 KB).
 * @copyright Copyright (c) 2026
 */

#include <stdio.h>
#include <pico/stdlib.h>
#include "eeprom_emulator.h"
#include "i2c_slave_handler.h"

void i2c_slave_handler(i2c_inst_t *i2c, i2c_slave_event_t event) {
    // Identify which hardware instance triggered the interrupt
    int bus_idx = (i2c == i2c0) ? 0 : 1;
    
    switch (event) {
        case I2C_SLAVE_RECEIVE: {
            // Retrieve byte sent by the I2C Master
            uint8_t rx_data = i2c_read_byte_raw(i2c);
            
            switch (eeprom.bus[bus_idx].state) {
                case EEPROM_STATE_WAIT_ADDRESS_HIGH:
                    // Store the high address byte (bits 15-8)
                    eeprom.bus[bus_idx].write_address_temp = ((uint16_t)rx_data << 8);
                    eeprom.bus[bus_idx].state = EEPROM_STATE_WAIT_ADDRESS_LOW;
                    break;
                    
                case EEPROM_STATE_WAIT_ADDRESS_LOW:
                    // Store the low address byte (bits 7-0)
                    eeprom.bus[bus_idx].write_address_temp |= rx_data;
                    
                    // Finalize write target address, mapping it to the capacity boundary
                    eeprom.bus[bus_idx].current_address = eeprom.bus[bus_idx].write_address_temp % EEPROM_SIZE_BYTES;
                    
                    // Advance to writing state, configuring page bounds trackers for this bus
                    eeprom.bus[bus_idx].state = EEPROM_STATE_WRITE_DATA;
                    eeprom.bus[bus_idx].page_start_address = eeprom.bus[bus_idx].current_address;
                    eeprom.bus[bus_idx].bytes_written_in_page = 0;
                    break;
                    
                case EEPROM_STATE_WRITE_DATA: {
                    // Compute page-wrapped write target address
                    uint16_t page_mask = EEPROM_PAGE_SIZE - 1;
                    uint16_t base_addr = eeprom.bus[bus_idx].page_start_address & ~page_mask;
                    uint16_t offset = (eeprom.bus[bus_idx].page_start_address + eeprom.bus[bus_idx].bytes_written_in_page) & page_mask;
                    uint16_t target_addr = (base_addr | offset) % EEPROM_SIZE_BYTES;
                    
                    // Write byte directly to the shared RAM memory array
                    eeprom.memory[target_addr] = rx_data;
                    eeprom.bus[bus_idx].transaction_dirty = true;
                    
                    LOG_DEBUG("[I2C%d] WRITE addr=0x%04X data=0x%02X\n", bus_idx, target_addr, rx_data);
                    
                    // Increment the bytes written in this page
                    eeprom.bus[bus_idx].bytes_written_in_page++;
                    
                    // Auto-increment bus pointer inside page
                    uint16_t next_offset = (eeprom.bus[bus_idx].page_start_address + eeprom.bus[bus_idx].bytes_written_in_page) & page_mask;
                    eeprom.bus[bus_idx].current_address = (base_addr | next_offset) % EEPROM_SIZE_BYTES;
                    break;
                }
                
                default:
                    break;
            }
            break;
        }
        
        case I2C_SLAVE_REQUEST: {
            // Master has queried a read byte from this device instance
            eeprom.bus[bus_idx].state = EEPROM_STATE_READ_DATA;
            
            // Read byte directly from the shared RAM memory array
            uint8_t tx_data = eeprom.memory[eeprom.bus[bus_idx].current_address];
            i2c_write_byte_raw(i2c, tx_data);
            
            LOG_DEBUG("[I2C%d] READ addr=0x%04X data=0x%02X\n", bus_idx, eeprom.bus[bus_idx].current_address, tx_data);
            
            // Auto-increment read pointer for this bus
            eeprom.bus[bus_idx].current_address = (eeprom.bus[bus_idx].current_address + 1) % EEPROM_SIZE_BYTES;
            break;
        }
        
        case I2C_SLAVE_FINISH: {
            // Transaction has closed or a Restart was received.
            // If data was updated during the transaction, trigger the background delay.
            if (eeprom.bus[bus_idx].transaction_dirty) {
#if (EEPROM_WRITE_DELAY_MS > 0)
                eeprom.is_writing_busy = true;
                eeprom.busy_start_time = get_absolute_time();
#endif
                eeprom.bus[bus_idx].transaction_dirty = false;
            }
            
            // Reset parser state for the next transaction
            eeprom.bus[bus_idx].state = EEPROM_STATE_WAIT_ADDRESS_HIGH;
            break;
        }
        
        default:
            break;
    }
}
