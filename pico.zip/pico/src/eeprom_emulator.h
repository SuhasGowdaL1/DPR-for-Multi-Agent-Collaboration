/**
 * @file eeprom_emulator.h
 * @brief Core structure and API declarations for the 64 KB Dual-I2C EEPROM Emulator.
 * @copyright Copyright (c) 2026
 */

#ifndef EEPROM_EMULATOR_H
#define EEPROM_EMULATOR_H

#include <stdint.h>
#include <stdbool.h>
#include <hardware/i2c.h>
#include "config.h"

/**
 * @brief State machine states for tracking I2C transactions (16-bit addressing).
 */
typedef enum {
    EEPROM_STATE_WAIT_ADDRESS_HIGH, /**< Waiting for MSB byte of 16-bit address */
    EEPROM_STATE_WAIT_ADDRESS_LOW,  /**< Waiting for LSB byte of the address */
    EEPROM_STATE_WRITE_DATA,        /**< Receiving data bytes to write to emulated array */
    EEPROM_STATE_READ_DATA          /**< Transmitting data bytes to the master */
} eeprom_state_t;

/**
 * @brief Structure containing the I2C transaction state for a single physical bus interface.
 */
typedef struct {
    uint16_t current_address;            /**< Current internal address pointer for this bus */
    uint16_t page_start_address;         /**< Reference starting address for current page write */
    uint16_t bytes_written_in_page;      /**< Total bytes received during current page write */
    uint16_t write_address_temp;         /**< Temporary address buffer during address phases */
    eeprom_state_t state;                /**< Current state machine execution state for this bus */
    volatile bool transaction_dirty;     /**< True if data was modified during current transaction on this bus */
} i2c_bus_context_t;

/**
 * @brief Structure containing the complete context state of the emulator.
 */
typedef struct {
    uint8_t memory[EEPROM_SIZE_BYTES];   /**< The RAM buffer emulating the memory array */
    
    // Separate Bus Contexts (index 0 for i2c0, index 1 for i2c1)
    i2c_bus_context_t bus[2];            /**< Independent I2C bus contexts */
    
    // Busy cycle flags
    volatile bool is_writing_busy;       /**< True when simulating write delay (NACKing) */
    volatile uint64_t busy_start_time;   /**< Timestamp indicating when the write busy cycle started */
} eeprom_emulator_t;

/**
 * @brief Global single instance of the emulator state context.
 */
extern eeprom_emulator_t eeprom;

// ============================================================================
// EMULATOR LIFECYCLE FUNCTIONS
// ============================================================================

/**
 * @brief Initializes the internal variables and registers of the emulator.
 */
void eeprom_emulator_init(void);

/**
 * @brief Background task scheduler function.
 * @details Manages the write delays and taking the hardware controllers offline/online.
 */
void eeprom_emulator_process_background(void);

#endif // EEPROM_EMULATOR_H
