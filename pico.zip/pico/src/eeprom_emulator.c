/**
 * @file eeprom_emulator.c
 * @brief Core utilities and background tasks scheduler for Dual-I2C (64 KB).
 * @copyright Copyright (c) 2026
 */

#include <stdio.h>
#include <string.h>
#include <hardware/sync.h>
#include <pico/i2c_slave.h>
#include <pico/stdlib.h>
#include "eeprom_emulator.h"
#include "i2c_slave_handler.h"

// Define the global instance of the emulator state
eeprom_emulator_t eeprom;

void eeprom_emulator_init(void) {
    // Zero out the context structure safely
    memset(&eeprom, 0, sizeof(eeprom));
    
    // Set initial parser state for both physical hardware buses
    for (int i = 0; i < 2; i++) {
        eeprom.bus[i].state = EEPROM_STATE_WAIT_ADDRESS_HIGH;
        eeprom.bus[i].transaction_dirty = false;
    }

    // Fill the RAM memory buffer with 0xFF
    memset(eeprom.memory, 0xFF, EEPROM_SIZE_BYTES);

    LOG_INFO("EEPROM initialized. Size: %u bytes, Page: %u bytes, I2C Address: 0x%02X\n", 
             EEPROM_SIZE_BYTES, EEPROM_PAGE_SIZE, EEPROM_I2C_ADDRESS);
}

void eeprom_emulator_process_background(void) {
    // Access status flags under interrupt lock protection
    uint32_t ints = save_and_disable_interrupts();
    bool busy = eeprom.is_writing_busy;
    uint64_t start_time = eeprom.busy_start_time;
    restore_interrupts(ints);
    
    if (busy) {
        LOG_INFO("Write transaction completed. Simulating self-timed write delay (%u ms)...\n", 
                 EEPROM_WRITE_DELAY_MS);

        // 1. Take both I2C0 and I2C1 hardware controllers offline to NACK the master during write cycle
        i2c_slave_deinit(i2c0);
        i2c_slave_deinit(i2c1);
        
        // 2. Spin until EEPROM_WRITE_DELAY_MS has fully elapsed since transaction finish
        uint64_t delay_us = (uint64_t)EEPROM_WRITE_DELAY_MS * 1000;
        while (absolute_time_diff_us(start_time, get_absolute_time()) < delay_us) {
            tight_loop_contents(); // Yield CPU slightly
        }
        
        // 3. Reset write busy cycles flags
        ints = save_and_disable_interrupts();
        eeprom.is_writing_busy = false;
        restore_interrupts(ints);
        
        // 4. Reinitialize both I2C0 and I2C1 hardware blocks back into I2C Slave Mode
        i2c_slave_init(i2c0, EEPROM_I2C_ADDRESS, &i2c_slave_handler);
        i2c_slave_init(i2c1, EEPROM_I2C_ADDRESS, &i2c_slave_handler);
        
        LOG_INFO("Write delay cycle complete. Devices online (ACKing).\n");
    }
}
