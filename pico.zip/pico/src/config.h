/**
 * @file config.h
 * @brief Configuration parameters and logging macros for the RP2040 I2C EEPROM Emulator.
 * @copyright Copyright (c) 2026
 */

#ifndef CONFIG_H
#define CONFIG_H

// ============================================================================
// LOGGING SUBSYSTEM DEFINITIONS
// ============================================================================
#define EEPROM_LOG_LEVEL_NONE  0  /**< No logs generated */
#define EEPROM_LOG_LEVEL_ERROR 1  /**< Only error logs generated */
#define EEPROM_LOG_LEVEL_INFO  2  /**< Standard operational logs generated */
#define EEPROM_LOG_LEVEL_DEBUG 3  /**< Verbose debug logs (useful for bus tracing) */

// ============================================================================
// SYSTEM CONFIGURATIONS (Customize your EEPROM device here)
// ============================================================================

/**
 * @brief Select the log output verbosity.
 * @details Options:
 * - EEPROM_LOG_LEVEL_NONE: Silent, fastest bus timing.
 * - EEPROM_LOG_LEVEL_ERROR: Errors only.
 * - EEPROM_LOG_LEVEL_INFO: Standard logs (initializations, write delays).
 * - EEPROM_LOG_LEVEL_DEBUG: Verbose traces of every Read/Write (slows down bus).
 */
#define EEPROM_LOG_LEVEL        EEPROM_LOG_LEVEL_INFO

/**
 * @brief EEPROM Storage Capacity in bytes.
 * @details Emulated capacities (standard sizes):
 * - 24LC256: 32768  (32 KB)
 * - 24LC512: 65536  (64 KB) (Default)
 */
#define EEPROM_SIZE_BYTES       65536

/**
 * @brief EEPROM Page Size in bytes.
 * @details Standard page sizes:
 * - 24LC256: 64
 * - 24LC512: 128 (Default)
 */
#define EEPROM_PAGE_SIZE        128

/**
 * @brief Address byte width.
 * @details Options:
 * - 1: 16-bit memory addresses (2 bytes) for capacities >= 4KB.
 * - 0: 8-bit memory addresses (1 byte) for smaller capacities.
 */
#define EEPROM_ADDR_16BIT       1

/**
 * @brief I2C 7-bit Device Address.
 * @details Default for 24LC series is 0x50.
 */
#define EEPROM_I2C_ADDRESS      0x50

/**
 * @brief Simulated write delay duration in milliseconds.
 * @details A physical 24LC series EEPROM takes up to 5 ms to complete a write cycle,
 * during which it NACKs any address query on the I2C bus.
 * Set to 0 to disable simulated delays (immediate ACK).
 */
#define EEPROM_WRITE_DELAY_MS   5

// ============================================================================
// HARDWARE / PERIPHERAL PINS CONFIGURATION
// ============================================================================

/**
 * @brief RP2040 physical hardware I2C instance to use.
 * @details Options: i2c0 or i2c1.
 */
#define EEPROM_I2C_INST         i2c0

/**
 * @brief GPIO pin assigned to I2C Serial Data (SDA).
 * @details GP4 maps to i2c0 SDA.
 */
#define EEPROM_I2C_SDA_PIN      4

/**
 * @brief GPIO pin assigned to I2C Serial Clock (SCL).
 * @details GP5 maps to i2c0 SCL.
 */
#define EEPROM_I2C_SCL_PIN      5

/**
 * @brief I2C Bus Baudrate speed.
 * @details Standard speeds:
 * - 100000: Standard Mode (100 kHz) (Default)
 * - 400000: Fast Mode (400 kHz)
 */
#define EEPROM_I2C_BAUDRATE     100000

// ============================================================================
// LOGGING MACROS
// ============================================================================
#if (EEPROM_LOG_LEVEL >= EEPROM_LOG_LEVEL_ERROR)
    #define LOG_ERROR(fmt, ...) printf("[ERROR] " fmt, ##__VA_ARGS__)
#else
    #define LOG_ERROR(fmt, ...) ((void)0)
#endif

#if (EEPROM_LOG_LEVEL >= EEPROM_LOG_LEVEL_INFO)
    #define LOG_INFO(fmt, ...)  printf("[INFO]  " fmt, ##__VA_ARGS__)
#else
    #define LOG_INFO(fmt, ...)  ((void)0)
#endif

#if (EEPROM_LOG_LEVEL >= EEPROM_LOG_LEVEL_DEBUG)
    #define LOG_DEBUG(fmt, ...) printf("[DEBUG] " fmt, ##__VA_ARGS__)
#else
    #define LOG_DEBUG(fmt, ...) ((void)0)
#endif

#endif // CONFIG_H
